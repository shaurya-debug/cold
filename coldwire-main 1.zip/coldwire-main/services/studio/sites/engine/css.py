"""Design-system CSS, generated per template.

Emitted as one inline `<style>` block so a page makes **zero** external requests
and renders on first paint. Structure:

    :root tokens   palette + type + layout knobs, set per template
    base           reset, fluid type scale, focus states
    components     buttons, chips, cards, forms, nav, lightbox
    layout skins   the per-template knobs that change structure, not just colour

Layout differences are driven by `Skin` (radius, density, rule weight, shadow
style, heading case). Two templates on the same palette should still feel like
different studios built them, so the knobs are structural rather than decorative.
"""

from __future__ import annotations

from dataclasses import dataclass

from .art import grain_data_uri
from .theme import Palette, TypeSystem, mix


@dataclass(frozen=True, slots=True)
class Skin:
    """Structural knobs. These are what make two templates feel unrelated."""

    radius: str = "0px"          # corner language
    density: float = 1.0         # section padding multiplier
    rule: str = "1px"            # hairline vs heavy rules
    shadow: str = "none"         # none | soft | offset
    measure: str = "68ch"        # max line length for prose
    container: str = "1180px"
    grain: float = 0.0           # film-grain overlay opacity (0 = off)
    hero_min: str = "88svh"
    letter_body: str = "0"
    surface_edge: bool = True    # draw rules between bands
    uppercase_nav: bool = True


BASE_CSS = """
*,*::before,*::after{box-sizing:border-box}
*{margin:0}
html{-webkit-text-size-adjust:100%;scroll-behavior:smooth}
@media (prefers-reduced-motion:reduce){
  html{scroll-behavior:auto}
  *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;
    transition-duration:.01ms!important;scroll-behavior:auto!important}
}
body{font-family:var(--font-body);background:var(--bg);color:var(--ink);
  line-height:1.62;letter-spacing:var(--letter-body);
  -webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;
  overflow-x:hidden}
img,svg,video{display:block;max-width:100%}
/* Artwork is drawn with `preserveAspectRatio=slice`, so shapes deliberately
   extend past the viewBox. That ink is clipped visually but still inflates
   scrollWidth; `contain:paint` stops it propagating (and lets the compositor
   skip the off-box work). */
.hero-art,.hero-visual,.about-art,.ed-art,.fr-art,.st-art,.tile,.map-frame,
.lb-stage{contain:paint}
/* Photographs paint their own 20px LQIP as a background while the file
   loads, so the slot is never a bare grey box on a slow connection. */
.ph{background-repeat:no-repeat;background-size:cover;background-position:center;background-color:var(--surface)}
button,input,textarea,select{font:inherit;color:inherit}
a{color:inherit}

/* ---- type scale: fluid, no media queries needed ---- */
h1,h2,h3,h4{font-family:var(--font-display);font-weight:var(--display-weight);
  letter-spacing:var(--display-spacing);line-height:1.08;text-wrap:balance;
  text-transform:var(--display-case)}
h1{font-size:clamp(2.4rem,6.2vw,5.1rem)}
h2{font-size:clamp(1.85rem,3.9vw,3.15rem);line-height:1.12}
h3{font-size:clamp(1.12rem,1.7vw,1.42rem);line-height:1.24;letter-spacing:-.01em}
p{text-wrap:pretty}
/* Scraped business names run long and occasionally contain a single token wider
   than its column ("VASTRABHARANAM", a bare URL). break-word only engages when
   a word genuinely cannot fit, so normal copy is unaffected. */
h1,h2,h3,h4,p,li,a,summary,cite,figcaption,label{overflow-wrap:break-word}
.lede{font-size:clamp(1.04rem,1.55vw,1.28rem);line-height:1.6;color:var(--ink-soft);
  max-width:var(--measure)}
.eyebrow{font-family:var(--font-eyebrow);font-size:.685rem;font-weight:600;
  letter-spacing:var(--eyebrow-spacing);text-transform:var(--eyebrow-case);
  color:var(--accent);display:block;margin-bottom:1.1rem}
.eyebrow.on-deep{color:var(--accent-lift)}

/* ---- layout ---- */
.wrap{width:min(100% - 2.5rem,var(--container));margin-inline:auto}
.wrap-narrow{width:min(100% - 2.5rem,760px);margin-inline:auto}
/* Grid and flex items default to min-width:auto, so a wide child (an inline SVG
   at its intrinsic size, a nowrap button label) can push a track past its share
   and scroll the whole page sideways. Every multi-column container opts out. */
.about-grid>*,.ed-grid>*,.hero-split>*,.price-card>*,.contact-grid>*,.st-row>*,
.cards>*,.quotes>*,.stats>*,.steps>*,.foot-grid>*,.svc-row>*,.nav>*{min-width:0}
section{padding-block:var(--section-pad);position:relative}
.band-surface{background:var(--surface)}
.band-deep{background:var(--deep);color:var(--deep-ink)}
.band-deep h1,.band-deep h2,.band-deep h3{color:var(--deep-ink)}
.band-deep .lede,.band-deep p{color:color-mix(in srgb,var(--deep-ink) 76%,transparent)}
.edge-top{border-top:var(--rule) solid var(--line)}
.sec-head{margin-bottom:clamp(2rem,4vw,3.4rem)}
.sec-head h2{max-width:20ch}
.sec-head .lede{margin-top:1.1rem}

/* ---- skip link + focus ---- */
.skip{position:absolute;left:-9999px;top:0;z-index:200;background:var(--accent);
  color:var(--accent-ink);padding:.85rem 1.3rem;border-radius:var(--radius)}
.skip:focus{left:.75rem;top:.75rem}
:focus-visible{outline:2.5px solid var(--accent);outline-offset:3px;border-radius:2px}

/* ---- buttons ---- */
.btn{display:inline-flex;align-items:center;gap:.6rem;padding:.95rem 1.7rem;
  border-radius:var(--radius);border:var(--rule) solid transparent;cursor:pointer;
  font-family:var(--font-eyebrow);font-size:.815rem;font-weight:650;
  letter-spacing:.09em;text-transform:uppercase;text-decoration:none;
  transition:transform .22s cubic-bezier(.2,.7,.3,1),background .22s,color .22s,
    box-shadow .22s;white-space:nowrap;line-height:1}
.btn-primary{background:var(--accent);color:var(--accent-ink);box-shadow:var(--shadow)}
.btn-primary:hover{transform:translateY(-2px);
  background:color-mix(in srgb,var(--accent) 86%,var(--ink));box-shadow:var(--shadow-lift)}
.btn-ghost{border-color:var(--line-strong);color:var(--ink);background:transparent}
.btn-ghost:hover{background:var(--ink);color:var(--bg);transform:translateY(-2px)}
.band-deep .btn-ghost{border-color:color-mix(in srgb,var(--deep-ink) 42%,transparent);
  color:var(--deep-ink)}
.band-deep .btn-ghost:hover{background:var(--deep-ink);color:var(--deep)}
.btn-lg{padding:1.15rem 2.1rem;font-size:.86rem}
.btn svg{width:1.05em;height:1.05em;flex:none}
/* Icons are <use> references into the page sprite; they inherit the
   symbol's viewBox but need an explicit box of their own. */
.ic{width:1.05em;height:1.05em;flex:none;fill:currentColor}
/* Long CTA labels ("Enquire about your wedding") are wider than a small phone
   once nowrap is honoured, which drags the whole hero column with them. */
@media (max-width:560px){
  .btn{white-space:normal;text-align:center;justify-content:center}
  .hero-actions .btn{width:100%}
}

/* ---- chips / meta ---- */
.chips{display:flex;flex-wrap:wrap;gap:.55rem}
.chip{display:inline-flex;align-items:center;gap:.42rem;padding:.44rem .88rem;
  border:var(--rule) solid var(--line);border-radius:999px;font-size:.775rem;
  color:var(--ink-soft);background:var(--bg);letter-spacing:.01em}
.band-deep .chip{border-color:color-mix(in srgb,var(--deep-ink) 26%,transparent);
  color:color-mix(in srgb,var(--deep-ink) 82%,transparent);background:transparent}
.chip .star{color:var(--accent)}
.band-deep .chip .star{color:var(--accent-lift)}

/* ---- header / nav ---- */
.site-head{position:sticky;top:0;z-index:90;background:color-mix(in srgb,var(--bg) 82%,transparent);
  backdrop-filter:blur(14px) saturate(1.5);-webkit-backdrop-filter:blur(14px) saturate(1.5);
  border-bottom:var(--rule) solid transparent;transition:border-color .3s,background .3s}
.site-head[data-stuck="1"]{border-bottom-color:var(--line);
  background:color-mix(in srgb,var(--bg) 94%,transparent)}
.nav{display:flex;align-items:center;justify-content:space-between;gap:1.5rem;
  min-height:var(--nav-h)}
/* The brand absorbs whatever space is left and ellipsises — some scraped names
   run 70+ characters ("… | Rental Photo Studio in Nashik | Studio for Photoshoot")
   and would otherwise push the nav CTA off the page. */
.brand{display:flex;align-items:center;gap:.7rem;text-decoration:none;
  flex:1 1 auto;min-width:0;margin-right:auto;padding-block:.3rem}
.brand-mark{width:2.5rem;height:2.5rem;flex:none;border-radius:var(--radius-mark);
  background:var(--accent);color:var(--accent-ink);display:grid;place-items:center;
  font-family:var(--font-brand);font-size:.9rem;font-weight:700;letter-spacing:.04em;
  line-height:1;position:relative;overflow:hidden;
  box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--accent-ink) 16%,transparent)}
/* A soft top-left highlight stops the monogram reading as a flat colour chip. */
.brand-mark::after{content:"";position:absolute;inset:0;pointer-events:none;
  background:linear-gradient(148deg,rgba(255,255,255,.22),rgba(255,255,255,0) 58%)}
.brand-mark span{position:relative;z-index:1}
.brand-text{display:flex;flex-direction:column;min-width:0;gap:.14rem}
/* The wordmark is NOT set in --font-display. At 17px a poster face
   (Haettenschweiler) collapses into an unreadable picket fence and a Didone
   loses its hairlines, so --font-brand is a separate legible face per type
   system, with tracking opened back up from the headline value. */
.brand-name{font-family:var(--font-brand);font-size:1.06rem;
  font-weight:var(--brand-weight);letter-spacing:-.005em;line-height:1.15;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--ink);
  font-feature-settings:"kern" 1;text-transform:none}
.brand-sub{font-family:var(--font-eyebrow);font-size:.645rem;font-weight:600;
  letter-spacing:.14em;text-transform:uppercase;
  color:color-mix(in srgb,var(--ink-soft) 88%,var(--bg));
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.brand:hover .brand-name{color:var(--accent)}
/* Below the nav breakpoint the second line costs more than it gives — the
   wordmark gets the full width instead. */
@media (max-width:520px){
  .brand-sub{display:none}
  .brand-mark{width:2.2rem;height:2.2rem;font-size:.8rem}
  .brand-name{font-size:1rem}
}
.nav-links{display:flex;align-items:center;gap:clamp(1rem,2.1vw,2rem);list-style:none;
  padding:0;flex:none}
.nav-links a{text-decoration:none;font-size:.815rem;letter-spacing:.075em;
  text-transform:var(--nav-case);color:var(--ink-soft);position:relative;
  padding-block:.35rem;transition:color .2s}
.nav-links a::after{content:"";position:absolute;left:0;right:100%;bottom:0;height:1.5px;
  background:var(--accent);transition:right .3s cubic-bezier(.2,.7,.3,1)}
.nav-links a:hover{color:var(--ink)}
.nav-links a:hover::after{right:0}
.nav-cta{display:flex;align-items:center;gap:.7rem;flex:none}
.nav-toggle{display:none;background:none;border:var(--rule) solid var(--line);
  border-radius:var(--radius);padding:.6rem .7rem;cursor:pointer}
.nav-toggle span{display:block;width:19px;height:1.6px;background:var(--ink);
  transition:transform .3s,opacity .2s}
.nav-toggle span+span{margin-top:4.5px}
.nav-toggle[aria-expanded="true"] span:nth-child(1){transform:translateY(6px) rotate(45deg)}
.nav-toggle[aria-expanded="true"] span:nth-child(2){opacity:0}
.nav-toggle[aria-expanded="true"] span:nth-child(3){transform:translateY(-6px) rotate(-45deg)}
@media (max-width:860px){
  .nav-toggle{display:block}
  /* A percentage translate is relative to the menu's own height, so a short
     menu never clears the header — 120px of links used to sit over the hero on
     every phone. visibility is height-independent and also removes the links
     from the tab order while closed. */
  .nav-links{position:fixed;inset:var(--nav-h) 0 auto;flex-direction:column;
    align-items:stretch;gap:0;background:var(--bg);border-bottom:var(--rule) solid var(--line);
    padding:.5rem 1.25rem 1.5rem;transform:translateY(-8px);opacity:0;
    visibility:hidden;pointer-events:none;
    transition:transform .32s cubic-bezier(.3,.9,.3,1),opacity .24s,visibility 0s .32s;
    box-shadow:0 24px 48px -28px rgba(0,0,0,.4);max-height:80svh;overflow-y:auto}
  .nav-links[data-open="1"]{transform:translateY(0);opacity:1;visibility:visible;
    pointer-events:auto;
    transition:transform .32s cubic-bezier(.3,.9,.3,1),opacity .24s,visibility 0s}
  .nav-links a{padding:.95rem 0;font-size:1rem;border-bottom:1px solid var(--line)}
  .nav-links li:last-child a{border-bottom:0}
  .nav-cta .btn{display:none}
}

/* ---- hero ---- */
.hero{position:relative;display:grid;align-items:center;isolation:isolate;
  min-height:var(--hero-min);overflow:hidden}
.hero-art{position:absolute;inset:0;z-index:-2}
.hero-art svg,.hero-art img{width:100%;height:100%;object-fit:cover}
.hero-scrim{position:absolute;inset:0;z-index:-1;
  background:linear-gradient(180deg,color-mix(in srgb,var(--deep) 62%,transparent) 0%,
    color-mix(in srgb,var(--deep) 30%,transparent) 42%,
    color-mix(in srgb,var(--deep) 78%,transparent) 100%)}
/* The gradient above was tuned against the procedural artwork, which is dark by
   construction and lightest exactly where it is thinnest. A photograph is not:
   a white mandap or a sunlit kitchen puts near-white pixels directly behind the
   headline. When a photo is in the slot the scrim gets a floor it never drops
   below, plus a vignette that darkens the corners where the chips and buttons
   sit. Measured against the brightest photo in the library, white text on this
   stack clears WCAG AA. */
.hero.on-photo .hero-scrim{
  background:
    linear-gradient(180deg,color-mix(in srgb,var(--deep) 82%,transparent) 0%,
      color-mix(in srgb,var(--deep) 58%,transparent) 34%,
      color-mix(in srgb,var(--deep) 68%,transparent) 62%,
      color-mix(in srgb,var(--deep) 90%,transparent) 100%),
    radial-gradient(130% 85% at 50% 42%,transparent 0%,
      color-mix(in srgb,var(--deep) 45%,transparent) 100%)}
/* A slight desaturation stops a hot orange sunset fighting the accent colour
   the buttons and eyebrow are painted in. */
.hero.on-photo .hero-art img{filter:saturate(.92) contrast(1.02)}
.hero-inner{padding-block:clamp(4rem,10vh,7rem);position:relative}
.hero.on-art .hero-inner,.hero.on-art h1{color:#fff}
.hero.on-art .lede{color:rgba(255,255,255,.9)}
.hero.on-art .eyebrow{color:var(--accent-lift)}
.hero.on-art .chip{border-color:rgba(255,255,255,.34);color:rgba(255,255,255,.94);
  background:rgba(0,0,0,.16)}
.hero.on-art .chip .star{color:var(--accent-lift)}
.hero.on-art .btn-ghost{border-color:rgba(255,255,255,.62);color:#fff}
.hero.on-art .btn-ghost:hover{background:#fff;color:var(--deep)}
.hero h1{margin-bottom:1.3rem;max-width:17ch}
.hero-actions{display:flex;flex-wrap:wrap;gap:.85rem;margin-top:2.1rem}
.hero-meta{margin-top:2.4rem}
.hero-split{display:grid;grid-template-columns:1fr 1fr;gap:0;align-items:stretch;
  min-height:var(--hero-min)}
.hero-split .hero-copy{display:flex;flex-direction:column;justify-content:center;
  padding:clamp(3rem,7vw,6rem) clamp(1.5rem,5vw,4.5rem)}
.hero-split .hero-visual{position:relative;overflow:hidden;min-height:46svh}
.hero-split .hero-visual svg,.hero-split .hero-visual img{position:absolute;inset:0;
  width:100%;height:100%;object-fit:cover}
@media (max-width:900px){.hero-split{grid-template-columns:1fr}}
/* Above that breakpoint the copy sits in a HALF-width column while the base h1
   size is a fraction of the whole viewport, so the two drift apart: between
   ~900px and ~1300px a ten-character word in a display face renders wider than
   its column and `overflow-wrap` splits it mid-word ("REMEMBERE D"). Sizing
   this hero's headline against half the viewport keeps them in step. The class
   selector also outranks the bare `h1` rule a template's CSS layer may set,
   which a media query on its own would not. */
@media (min-width:901px){
  .hero-split h1{font-size:clamp(2.4rem,4.6vw,4.6rem)}
}

/* ---- hero variants ---- */
/* These three drop the flex centring and lay out in normal flow, which means
   they also inherit `section`'s padding on top of `.hero-inner`'s own — about
   190px of dead space above the eyebrow at 1440px, on half the templates.
   `.hero-inner` owns hero spacing; the section contributes none. */
.hero-ed,.hero-fr,.hero-st{min-height:auto;display:block;padding-block:0}
.hero-ed .ed-grid{display:grid;grid-template-columns:1.08fr .92fr;
  gap:clamp(2rem,5vw,4.5rem);align-items:center}
.hero-ed .ed-art{aspect-ratio:4/5;overflow:hidden;border-radius:var(--radius);
  box-shadow:var(--shadow-lift)}
.hero-ed .ed-art svg,.hero-ed .ed-art img{width:100%;height:100%;object-fit:cover}
/* The editorial hero puts the headline in a ~55% column, so it must cap below
   the page-wide h1 size — templates using CSS_BIG_TYPE otherwise wrap to five
   lines and collide with the artwork. */
.hero-ed h1{max-width:14ch;font-size:clamp(2.2rem,4.4vw,3.9rem)}
@media (max-width:900px){.hero-ed .ed-grid{grid-template-columns:1fr}
  .hero-ed .ed-art{aspect-ratio:16/11;order:-1}}
.hero-fr .fr-art{margin-top:clamp(2.4rem,5vw,3.6rem);aspect-ratio:16/8;
  overflow:hidden;border-radius:var(--radius);box-shadow:var(--shadow-lift)}
.hero-fr .fr-art svg,.hero-fr .fr-art img{width:100%;height:100%;object-fit:cover}
.hero-fr h1{max-width:16ch}
.hero-st .st-row{display:grid;grid-template-columns:1.2fr auto;gap:clamp(1.5rem,4vw,3rem);
  align-items:end;margin-top:1.6rem}
.hero-st .st-art{margin-top:clamp(2.4rem,5vw,3.6rem);aspect-ratio:21/8;overflow:hidden}
.hero-st .st-art svg,.hero-st .st-art img{width:100%;height:100%;object-fit:cover}
.hero-st .hero-actions{margin-top:0}
@media (max-width:820px){.hero-st .st-row{grid-template-columns:1fr;align-items:start}
  .hero-st .hero-actions{margin-top:1.4rem}}

/* ---- about ---- */
.about-grid{display:grid;grid-template-columns:.85fr 1.15fr;gap:clamp(2rem,5vw,4.5rem);
  align-items:center}
.about-art{aspect-ratio:4/5;overflow:hidden;border-radius:var(--radius);
  box-shadow:var(--shadow-lift)}
.about-art svg,.about-art img{width:100%;height:100%;object-fit:cover}
.about-copy h2{margin-bottom:1.4rem}
.prose{display:grid;gap:1.1rem;color:var(--ink-soft);max-width:var(--measure)}
.prose p:first-child{font-size:1.08rem;color:var(--ink)}
@media (max-width:880px){.about-grid{grid-template-columns:1fr}
  .about-art{aspect-ratio:16/11}}

/* ---- pricing ---- */
.price-card{display:grid;grid-template-columns:1.4fr auto;gap:clamp(1.6rem,4vw,3.5rem);
  align-items:center;padding:clamp(1.9rem,4vw,3.2rem);border-radius:var(--radius);
  border:var(--rule) solid var(--line);background:var(--surface)}
.price-card h2{margin:.4rem 0 1rem}
@media (max-width:760px){.price-card{grid-template-columns:1fr}}

/* ---- gallery ---- */
.gal{display:grid;gap:var(--gap)}
.gal-grid{grid-template-columns:repeat(auto-fit,minmax(min(100%,265px),1fr))}
/* row-gap MUST stay 0. A `grid-row:span 26` crosses 25 row gaps as well as 26
   tracks, so with a 25px gap each tile resolved to 26*11+25*25 = 911px instead
   of the intended ~290px. The procedural artwork sliced to fit and hid it; a
   photograph does not, and every masonry wall came out as vertical ribbons.
   With the gap at zero a span is exactly N*11px, and the visual gutter comes
   from the tile's own padding instead. */
.gal-masonry{grid-template-columns:repeat(auto-fit,minmax(min(100%,265px),1fr));
  grid-auto-rows:11px;align-items:stretch;row-gap:0}
/* Row spans set the height here, so the tile's own aspect-ratio must be
   dropped — leaving both on makes each tile shorter than its grid cell and
   tears holes in the wall. */
.gal-masonry .tile{aspect-ratio:auto;height:100%;overflow:visible;
  background:transparent;padding-bottom:var(--gap)}
.gal-masonry .tile>figure{inset:0 0 var(--gap) 0;overflow:hidden;
  border-radius:var(--radius);background:var(--surface)}
.gal-mosaic{grid-template-columns:repeat(4,1fr)}
.gal-mosaic .tile:nth-child(1){grid-column:span 2;grid-row:span 2}
.gal-mosaic .tile:nth-child(6){grid-column:span 2}
@media (max-width:820px){.gal-mosaic{grid-template-columns:repeat(2,1fr)}
  .gal-mosaic .tile:nth-child(1){grid-column:span 2;grid-row:span 1}}
.gal-strip{display:flex;gap:var(--gap);overflow-x:auto;scroll-snap-type:x mandatory;
  padding-bottom:1.1rem;scrollbar-width:thin}
.gal-strip .tile{flex:0 0 clamp(230px,32vw,390px);scroll-snap-align:start}
.tile{position:relative;overflow:hidden;border-radius:var(--radius);
  background:var(--surface);aspect-ratio:var(--tile-ratio);cursor:zoom-in;
  border:none;padding:0;display:block;width:100%;
  transition:transform .5s cubic-bezier(.2,.7,.3,1)}
/* The figure is stretched to the tile so the SVG's height:100% has a definite
   box to resolve against. Without this the SVG falls back to its viewBox ratio
   and any tile whose height comes from elsewhere (masonry row spans, mosaic
   row spans) shows dead space. */
.tile>figure{margin:0;position:absolute;inset:0}
.tile svg,.tile img{width:100%;height:100%;object-fit:cover;
  transition:transform .7s cubic-bezier(.2,.7,.3,1)}
.tile:hover svg,.tile:hover img{transform:scale(1.06)}
.tile figcaption{position:absolute;left:0;right:0;bottom:0;padding:1.5rem 1.1rem .85rem;
  font-family:var(--font-eyebrow);font-size:.68rem;letter-spacing:.16em;
  text-transform:uppercase;color:#fff;text-align:left;
  background:linear-gradient(transparent,rgba(0,0,0,.62));
  opacity:0;transform:translateY(6px);transition:opacity .3s,transform .3s}
.tile:hover figcaption,.tile:focus-visible figcaption{opacity:1;transform:none}

/* ---- lightbox ---- */
.lb{position:fixed;inset:0;z-index:120;background:rgba(8,8,10,.94);display:none;
  place-items:center;padding:clamp(1rem,4vw,3rem)}
.lb[open]{display:grid}
.lb::backdrop{background:rgba(8,8,10,.94)}
.lb-stage{width:min(94vw,1080px);aspect-ratio:4/3;border-radius:var(--radius);
  overflow:hidden;background:#111}
.lb-stage svg,.lb-stage img{width:100%;height:100%;object-fit:contain;background:#111}
.lb-cap{color:#fff;text-align:center;margin-top:1.1rem;font-size:.8rem;
  letter-spacing:.14em;text-transform:uppercase;opacity:.75}
.lb-close,.lb-prev,.lb-next{position:absolute;background:rgba(255,255,255,.1);
  border:1px solid rgba(255,255,255,.24);color:#fff;width:2.9rem;height:2.9rem;
  border-radius:50%;cursor:pointer;display:grid;place-items:center;font-size:1.1rem;
  transition:background .2s}
.lb-close:hover,.lb-prev:hover,.lb-next:hover{background:rgba(255,255,255,.22)}
.lb-close{top:1.1rem;right:1.1rem}
.lb-prev{left:1.1rem;top:50%;transform:translateY(-50%)}
.lb-next{right:1.1rem;top:50%;transform:translateY(-50%)}

/* ---- cards / services ---- */
.cards{display:grid;gap:var(--gap);
  grid-template-columns:repeat(auto-fit,minmax(min(100%,285px),1fr))}
.card{padding:clamp(1.6rem,2.6vw,2.3rem);border-radius:var(--radius);
  background:var(--bg);border:var(--rule) solid var(--line);
  transition:transform .3s cubic-bezier(.2,.7,.3,1),border-color .3s,box-shadow .3s;
  position:relative;overflow:hidden}
.band-surface .card{background:var(--bg)}
.card:hover{transform:translateY(-4px);border-color:var(--accent);box-shadow:var(--shadow-lift)}
.card h3{margin-bottom:.7rem}
.card p{color:var(--ink-soft);font-size:.945rem}
.card-num{font-family:var(--font-eyebrow);font-size:.7rem;letter-spacing:.2em;
  color:var(--accent);display:block;margin-bottom:1rem}
.card-rule{width:2.2rem;height:2px;background:var(--accent);margin-bottom:1.3rem}

/* list-style services (no boxes) */
.svc-list{display:grid;gap:0;border-top:var(--rule) solid var(--line)}
.svc-row{display:grid;grid-template-columns:auto 1fr;gap:clamp(1rem,4vw,3.5rem);
  padding:clamp(1.5rem,2.8vw,2.3rem) 0;border-bottom:var(--rule) solid var(--line);
  align-items:start;transition:padding-left .3s}
.svc-row:hover{padding-left:.7rem}
.svc-row .n{font-family:var(--font-eyebrow);font-size:.7rem;letter-spacing:.18em;
  color:var(--accent);padding-top:.45rem}
.svc-row p{color:var(--ink-soft);margin-top:.55rem;max-width:58ch;font-size:.955rem}

/* ---- stats ---- */
.stats{display:grid;gap:var(--gap);
  grid-template-columns:repeat(auto-fit,minmax(min(100%,132px),1fr))}
.stat{padding:clamp(1.2rem,2vw,1.8rem) 0}
/* Values are data, not headlines: "₹3,50,000" is one unbreakable token, and at
   the old 3rem it was wider than its track — enough to push the whole two-column
   about grid past the page. Sized to fit the narrowest track, and allowed to
   break as a last resort. */
.stat .v{font-family:var(--font-display);font-size:clamp(1.55rem,2.7vw,2.35rem);
  line-height:1.04;letter-spacing:-.025em;color:var(--accent);display:block;
  overflow-wrap:anywhere}
.band-deep .stats .stat .v{font-size:clamp(1.7rem,3.2vw,2.7rem)}
/* `overflow-wrap:anywhere` above stops a long value from dragging the grid off
   the page, but it does that by splitting the token — and a *place name* split
   as "Visakhapatna m" reads as broken rather than as data. A number wants to be
   big and a city name cannot be, so the value is sized by its longest token at
   build time. `--stat-fit` carries that decision; the deep band scales it up
   the same way the base size does. */
.stat .v.v-mid{font-size:clamp(1.15rem,1.9vw,1.5rem);letter-spacing:-.01em}
.stat .v.v-long{font-size:clamp(.95rem,1.45vw,1.1rem);letter-spacing:0;
  line-height:1.2}
.band-deep .stats .stat .v.v-mid{font-size:clamp(1.25rem,2.1vw,1.62rem)}
.band-deep .stats .stat .v.v-long{font-size:clamp(1rem,1.55vw,1.18rem)}
.band-deep .stat .v{color:var(--accent-lift)}
.stat .l{font-size:.71rem;letter-spacing:.17em;text-transform:uppercase;
  color:var(--ink-soft);margin-top:.75rem;display:block}
.band-deep .stat .l{color:color-mix(in srgb,var(--deep-ink) 68%,transparent)}

/* ---- process ---- */
.steps{display:grid;gap:var(--gap);counter-reset:step;
  grid-template-columns:repeat(auto-fit,minmax(min(100%,215px),1fr))}
.step{position:relative;padding-top:2.6rem}
.step::before{counter-increment:step;content:counter(step,decimal-leading-zero);
  position:absolute;top:0;left:0;font-family:var(--font-eyebrow);font-size:.72rem;
  letter-spacing:.2em;color:var(--accent)}
.step::after{content:"";position:absolute;top:.42rem;left:2.6rem;right:0;height:var(--rule);
  background:var(--line)}
.step:last-child::after{display:none}
.step h3{font-size:1.03rem;margin-bottom:.5rem}
.step p{color:var(--ink-soft);font-size:.92rem}

/* ---- quotes ---- */
.quotes{display:grid;gap:var(--gap);
  grid-template-columns:repeat(auto-fit,minmax(min(100%,285px),1fr))}
.quote{padding:clamp(1.6rem,2.6vw,2.2rem);border-radius:var(--radius);
  border:var(--rule) solid var(--line);background:var(--bg);position:relative;
  display:flex;flex-direction:column;gap:1.1rem}
.quote p{font-family:var(--font-display);font-size:1.09rem;line-height:1.46;
  letter-spacing:-.005em}
.quote.is-sample p{color:var(--ink-soft);font-style:italic}
.quote cite{font-style:normal;font-size:.735rem;letter-spacing:.15em;
  text-transform:uppercase;color:var(--ink-soft);margin-top:auto}
.sample-tag{position:absolute;top:.85rem;right:.85rem;font-size:.6rem;letter-spacing:.15em;
  text-transform:uppercase;padding:.28rem .6rem;border-radius:999px;
  background:color-mix(in srgb,var(--accent) 12%,transparent);color:var(--accent);
  border:1px solid color-mix(in srgb,var(--accent) 26%,transparent);font-weight:600}

/* ---- faq (native details, no JS) ---- */
.faq{border-top:var(--rule) solid var(--line);max-width:860px}
.faq details{border-bottom:var(--rule) solid var(--line)}
.faq summary{display:flex;justify-content:space-between;align-items:center;gap:1.5rem;
  padding:1.35rem 0;cursor:pointer;list-style:none;font-family:var(--font-display);
  font-size:clamp(1rem,1.5vw,1.16rem);font-weight:var(--display-weight);
  letter-spacing:-.01em;transition:color .2s}
.faq summary::-webkit-details-marker{display:none}
.faq summary:hover{color:var(--accent)}
.faq summary::after{content:"";width:.78rem;height:.78rem;flex:none;
  border-right:1.8px solid var(--accent);border-bottom:1.8px solid var(--accent);
  transform:rotate(45deg) translate(-2px,-2px);transition:transform .3s}
.faq details[open] summary::after{transform:rotate(-135deg) translate(-3px,-3px)}
.faq .a{padding:0 0 1.5rem;color:var(--ink-soft);max-width:64ch}

/* ---- contact / form ---- */
.contact-grid{display:grid;gap:clamp(2rem,5vw,4rem);
  grid-template-columns:repeat(auto-fit,minmax(min(100%,310px),1fr))}
.field{display:flex;flex-direction:column;gap:.5rem;margin-bottom:1.05rem}
.field label{font-size:.71rem;letter-spacing:.15em;text-transform:uppercase;
  color:var(--ink-soft);font-weight:600}
.field input,.field textarea,.field select{padding:.88rem 1rem;border-radius:var(--radius);
  border:var(--rule) solid var(--line-strong);background:var(--bg);color:var(--ink);
  transition:border-color .2s,box-shadow .2s;width:100%;font-size:.97rem}
.field input:focus,.field textarea:focus,.field select:focus{outline:none;
  border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 16%,transparent)}
.field textarea{resize:vertical;min-height:6.5rem}
.form-note{font-size:.79rem;color:var(--ink-soft);margin-top:.9rem;line-height:1.5}
.contact-list{list-style:none;padding:0;display:grid;gap:1.15rem}
.contact-list a{text-decoration:none;display:flex;gap:.95rem;align-items:flex-start;
  padding:.3rem 0;transition:color .2s}
.contact-list a:hover{color:var(--accent)}
.contact-list .ic{width:2.5rem;height:2.5rem;flex:none;border-radius:var(--radius-mark);
  border:var(--rule) solid var(--line);display:grid;place-items:center;color:var(--accent)}
.contact-list .ic svg{width:1.05rem;height:1.05rem}
.contact-list .k{font-size:.68rem;letter-spacing:.16em;text-transform:uppercase;
  color:var(--ink-soft);display:block;margin-bottom:.18rem}
.contact-list .v{font-size:1rem;line-height:1.35;word-break:break-word}

/* ---- cta band ---- */
.cta-band{text-align:center}
.cta-band h2{max-width:22ch;margin-inline:auto}
.cta-band .lede{margin:1.2rem auto 0;text-align:center}
.cta-band .hero-actions{justify-content:center}

/* ---- footer ---- */
.site-foot{padding-block:clamp(3rem,6vw,4.5rem) 2rem;border-top:var(--rule) solid var(--line)}
.foot-grid{display:grid;gap:2.4rem;grid-template-columns:repeat(auto-fit,minmax(min(100%,215px),1fr));
  margin-bottom:2.8rem}
.foot-grid h4{font-size:.69rem;letter-spacing:.18em;text-transform:uppercase;
  color:var(--ink-soft);margin-bottom:1.05rem;font-family:var(--font-eyebrow);font-weight:600}
.foot-grid ul{list-style:none;padding:0;display:grid;gap:.62rem}
/* Emails and Instagram handles are single unbreakable tokens and routinely run
   wider than a footer column at tablet widths. */
.foot-grid li,.foot-grid a{overflow-wrap:anywhere}
.foot-grid a{text-decoration:none;color:var(--ink-soft);font-size:.925rem;transition:color .2s}
.foot-grid a:hover{color:var(--accent)}
.foot-bottom{display:flex;flex-wrap:wrap;gap:1rem;justify-content:space-between;
  align-items:center;padding-top:1.8rem;border-top:var(--rule) solid var(--line);
  font-size:.79rem;color:var(--ink-soft)}

/* ---- floating WhatsApp ---- */
.fab{position:fixed;right:clamp(.9rem,2.5vw,1.6rem);bottom:clamp(.9rem,2.5vw,1.6rem);
  z-index:95;display:inline-flex;align-items:center;gap:.6rem;padding:.85rem 1.25rem;
  border-radius:999px;background:#1faa53;color:#fff;text-decoration:none;font-weight:650;
  font-size:.87rem;box-shadow:0 12px 30px -10px rgba(0,0,0,.45);
  transition:transform .25s cubic-bezier(.2,.7,.3,1),box-shadow .25s}
.fab:hover{transform:translateY(-3px) scale(1.02);box-shadow:0 18px 38px -12px rgba(0,0,0,.5)}
.fab svg{width:1.28rem;height:1.28rem;flex:none}
@media (max-width:560px){.fab span{display:none}.fab{padding:1rem;border-radius:50%}}

/* ---- demo ribbon ---- */
.demo-bar{background:var(--deep);color:var(--deep-ink);font-size:.76rem;
  padding:.6rem 1rem;text-align:center;letter-spacing:.04em}
.demo-bar b{color:var(--accent-lift);font-weight:650}
.demo-bar a{color:var(--deep-ink)}

/* ---- scroll reveal ---- */
.rv{opacity:0;transform:translateY(20px);
  transition:opacity .75s cubic-bezier(.2,.7,.3,1),transform .75s cubic-bezier(.2,.7,.3,1)}
.rv.in{opacity:1;transform:none}
@media (prefers-reduced-motion:reduce){.rv{opacity:1;transform:none}}

/* ---- map ---- */
.map-frame{border-radius:var(--radius);overflow:hidden;border:var(--rule) solid var(--line);
  aspect-ratio:16/10;background:var(--surface);position:relative}
.map-frame svg{width:100%;height:100%}
.map-pin{position:absolute;inset:0;display:grid;place-items:center;text-align:center;
  padding:1.5rem}
.map-pin .box{background:color-mix(in srgb,var(--bg) 92%,transparent);
  padding:1.15rem 1.4rem;border-radius:var(--radius);border:var(--rule) solid var(--line);
  max-width:34ch;backdrop-filter:blur(6px)}
.map-pin .box strong{display:block;margin-bottom:.35rem}
.map-pin .box span{font-size:.87rem;color:var(--ink-soft)}
"""


def build_css(pal: Palette, ts: TypeSystem, skin: Skin, extra: str = "") -> str:
    """Assemble tokens + base + per-template overrides into one stylesheet."""
    line = mix(pal.ink, pal.bg, 0.14)
    line_strong = mix(pal.ink, pal.bg, 0.28)
    # An accent readable against the dark band — the raw accent is tuned for the
    # light page and would fail contrast on `deep`.
    accent_lift = mix(pal.accent, "#ffffff", 0.42)

    shadows = {
        "none": ("none", "none"),
        "soft": ("0 10px 24px -14px rgba(0,0,0,.28)", "0 22px 44px -20px rgba(0,0,0,.34)"),
        "offset": (f"5px 5px 0 0 {line_strong}", f"8px 8px 0 0 {pal.accent}"),
    }
    shadow, shadow_lift = shadows.get(skin.shadow, shadows["none"])
    pad = f"clamp({3.2 * skin.density:.2f}rem,{6.4 * skin.density:.2f}vw,{7.0 * skin.density:.2f}rem)"

    grain = ""
    if skin.grain > 0:
        grain = (
            "body::after{content:'';position:fixed;inset:0;z-index:150;pointer-events:none;"
            f"background-image:url(\"{grain_data_uri(skin.grain)}\");"
            "mix-blend-mode:overlay;opacity:.5}"
        )

    tokens = f""":root{{
  --bg:{pal.bg};--surface:{pal.surface};--ink:{pal.ink};--ink-soft:{pal.ink_soft};
  --accent:{pal.accent};--accent-ink:{pal.accent_ink};--accent-lift:{accent_lift};
  --deep:{pal.deep};--deep-ink:{pal.deep_ink};
  --line:{line};--line-strong:{line_strong};
  --font-display:{ts.display};--font-body:{ts.body};--font-eyebrow:{ts.eyebrow};
  --font-brand:{ts.brand_face};--brand-weight:{ts.brand_weight};
  --display-weight:{ts.display_weight};--display-spacing:{ts.display_spacing};
  --display-case:{ts.display_case};
  --eyebrow-spacing:{ts.eyebrow_spacing};--eyebrow-case:{ts.eyebrow_case};
  --nav-case:{"uppercase" if skin.uppercase_nav else "none"};
  --radius:{skin.radius};--radius-mark:{skin.radius if skin.radius != "0px" else "2px"};
  --rule:{skin.rule};--shadow:{shadow};--shadow-lift:{shadow_lift};
  --container:{skin.container};--measure:{skin.measure};
  --section-pad:{pad};--gap:clamp(1rem,1.9vw,1.6rem);
  --nav-h:4.7rem;--hero-min:{skin.hero_min};--tile-ratio:4/5;
  --letter-body:{skin.letter_body};
}}"""

    edge = "" if skin.surface_edge else ".edge-top{border-top:0}"
    return "".join((tokens, BASE_CSS, grain, edge, extra))
